ANI DRIVE modern website starter

Included:
- index.html — responsive driving school website
- Armenian, Russian and English content
- Courses, about, registration, contact and app download placeholder
- manifest.webmanifest and sw.js (PWA/offline foundation)

Local preview: open index.html in a browser.
Hosting: upload the contents of this folder to a static host such as Vercel or Cloudflare Pages.

Important:
- The registration form currently opens an SMS draft to +37441334477; it does not store submissions online.
- No real admin dashboard, database, authentication or instructor profiles are connected.
- No APK is included yet. A native Android app must be built, signed and tested separately.
- The APK button is intentionally not active until a real APK is available.
